/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.base;

import dao.callback.PsBack;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import util.DbUtil;


/**
 *  
 *  @author wind
 */
public abstract class BaseDaoImpl<R, PK> implements BaseDao<R, PK>{

    /**
     * 
     * @param rs
     * @return
     * @throws SQLException
     */
    public abstract R parseTable(ResultSet rs) throws SQLException;


    /**
     * 
     * @param sql
     */
    public List<R> executeQuery(String sql){
        return executeQuery(sql, null);
    }

    /**
     * 
     * @param sql
     * @param psBack
     */
    public List<R> executeQuery(String sql, PsBack psBack){
        List<R> rList = new ArrayList<>();
        Connection conn = DbUtil.getConnection();
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            if(psBack != null){
                psBack.call(ps);
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                rList.add(parseTable(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DbUtil.close(conn);
        }

        return rList;
    }

    /**
     * 
     * @param sql
     * @param psBack
     * @return
     */
    public int executeUpdate(String sql, PsBack psBack){
        Connection conn = DbUtil.getConnection();
        int i = -1;
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            psBack.call(ps);
            i = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DbUtil.close(conn);
        }
        return i;
    }
}
