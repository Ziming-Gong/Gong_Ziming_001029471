package dao.impl;

import dao.MaterialDao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import dao.base.BaseDaoImpl;
import model.Material;
import model.LibOrder;
import dao.LibOrderDao;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * CRUD(create, read, update, delete)
 * @author wind
 *
 */
public class LibOrderDaoImpl extends BaseDaoImpl<LibOrder, Integer> implements LibOrderDao{

    
    
    /**
     *
     * @param order
     * @return
     */
    @Override
    public int insert(LibOrder order) {
        String sql = "insert into lib_order (book_id, count, user_id,request_time) values(?, ?, ?, ?)";
        return super.executeUpdate(sql, ps -> {
            ps.setInt(1, order.getBookId());
            ps.setInt(2, order.getCount());
            ps.setInt(3, order.getUserId());
            ps.setTimestamp(4, new Timestamp(order.getRequestTime().getTime()));
        });
    }

    /**
     * 
     * @param id
     * @return
     */
    @Override
    public int deleteById(Integer id) {
        String sql = "delete from lib_order where id = ?";
        return super.executeUpdate(sql, ps -> ps.setInt(1, id));
    }

    /**
     * 
     * @param id
     * @return
     */
    @Override
    public LibOrder findById(Integer id) {
        String sql = "select * from lib_order where id = ?";
        List<LibOrder> list = super.executeQuery(sql, ps -> ps.setInt(1, id));
        if(list.size() == 1){
            return list.get(0);
        }
        return null;
    }


    /**
     * 
     * @return
     */
    @Override
    public List<LibOrder> findByCondition(LibOrder order) {
        String sql = "select o.*, b.name book_name, u.username from lib_order o left join book b on o.book_id = b.id left join user u on o.user_id = u.id where 1=1 ";
        String whereClause = "";

        String name = order.getBookName();
        if(name != null){
            whereClause += "and b.name like '%" + name + "%' ";
        }
        Integer userId = order.getUserId();
        if(userId != null){
            whereClause += "and u.id = '" + userId + "' ";
        }
        Integer providerId = order.getProviderId();
        if(providerId != null){
            whereClause += "and b.user_id = '" + providerId + "' ";
        }
        sql += whereClause;
        return super.executeQuery(sql, ps -> {
            
        });
    }

    /**
     * 
     * @return
     */
    @Override
    public int updateConditionById(LibOrder order) {
        String sql = "update lib_order ";
        String setSql = "set ";
        Date resolveTime = order.getResolveTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if(resolveTime != null){
            setSql += ("resolve_time = '" + format.format(resolveTime) + "', ");
        }
        Integer id = order.getId();
        if(id != null && setSql.contains(",")){
            sql += setSql.substring(0, setSql.length() - 2);
            sql += " where id = ?";

            return super.executeUpdate(sql, ps -> ps.setInt(1, id));
        }
        return -1;
    }


    @Override
    public LibOrder parseTable(ResultSet rs) throws SQLException {
        LibOrder order = new LibOrder();
        order.setId(rs.getInt("id"));
        order.setBookId(rs.getInt("book_id"));
        try{
            order.setBookName(rs.getString("book_name"));
            order.setUsername(rs.getString("username"));
        }catch(Exception e){
            
        }
        order.setCount(rs.getInt("count"));
        order.setUserId(rs.getInt("user_id"));
        order.setRequestTime(rs.getTimestamp("request_time"));
        order.setResolveTime(rs.getTimestamp("resolve_time"));
        return order;
    }
}
