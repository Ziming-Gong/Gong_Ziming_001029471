package dao.impl;

import dao.MaterialDao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import dao.base.BaseDaoImpl;
import model.Material;
import model.LibOrder;
import dao.LibOrderDao;
import dao.ProviderOrderDao;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import model.ProviderOrder;

/**
 * CRUD(create, read, update, delete)
 * @author wind
 *
 */
public class ProviderOrderDaoImpl extends BaseDaoImpl<ProviderOrder, Integer> implements ProviderOrderDao{

    
    
    /**
     *
     * @param order
     * @return
     */
    @Override
    public int insert(ProviderOrder order) {
        String sql = "insert into provider_order (material_id, count, user_id,request_time) values(?, ?, ?, ?)";
        return super.executeUpdate(sql, ps -> {
            ps.setInt(1, order.getMaterialId());
            ps.setInt(2, order.getCount());
            ps.setInt(3, order.getUserId());
            ps.setTimestamp(4, new Timestamp(order.getRequestTime().getTime()));
        });
    }

    /**
     * 
     * @param id
     * @return
     */
    @Override
    public int deleteById(Integer id) {
        String sql = "delete from provider_order where id = ?";
        return super.executeUpdate(sql, ps -> ps.setInt(1, id));
    }

    /**
     * 
     * @param id
     * @return
     */
    @Override
    public ProviderOrder findById(Integer id) {
        String sql = "select * from provider_order where id = ?";
        List<ProviderOrder> list = super.executeQuery(sql, ps -> ps.setInt(1, id));
        if(list.size() == 1){
            return list.get(0);
        }
        return null;
    }


    /**
     * 
     * @return
     */
    @Override
    public List<ProviderOrder> findByCondition(ProviderOrder order) {
        String sql = "select o.*, b.name material_name, u.username from provider_order o left join material b on o.material_id = b.id left join user u on o.user_id = u.id where 1=1 ";
        String whereClause = "";

        String name = order.getMaterialName();
        if(name != null){
            whereClause += "and b.name like '%" + name + "%' ";
        }
        Integer userId = order.getUserId();
        if(userId != null){
            whereClause += "and u.id = '" + userId + "' ";
        }
        Integer printId = order.getPrintId();
        if(printId != null){
            whereClause += "and b.user_id = '" + printId + "' ";
        }
        sql += whereClause;
        return super.executeQuery(sql, ps -> {
            
        });
    }

    /**
     * 
     * @return
     */
    @Override
    public int updateConditionById(ProviderOrder order) {
        String sql = "update provider_order ";
        String setSql = "set ";
        Date resolveTime = order.getResolveTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if(resolveTime != null){
            setSql += ("resolve_time = '" + format.format(resolveTime) + "', ");
        }
        Integer id = order.getId();
        if(id != null && setSql.contains(",")){
            sql += setSql.substring(0, setSql.length() - 2);
            sql += " where id = ?";

            return super.executeUpdate(sql, ps -> ps.setInt(1, id));
        }
        return -1;
    }


    @Override
    public ProviderOrder parseTable(ResultSet rs) throws SQLException {
        ProviderOrder order = new ProviderOrder();
        order.setId(rs.getInt("id"));
        order.setMaterialId(rs.getInt("material_id"));
        try{
            order.setMaterialName(rs.getString("material_name"));
            order.setUsername(rs.getString("username"));
        }catch(Exception e){
            
        }
        order.setCount(rs.getInt("count"));
        order.setUserId(rs.getInt("user_id"));
        order.setRequestTime(rs.getTimestamp("request_time"));
        order.setResolveTime(rs.getTimestamp("resolve_time"));
        return order;
    }
}
