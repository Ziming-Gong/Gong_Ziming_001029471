package dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.Book;
import dao.base.BaseDaoImpl;
import dao.BookDao;
import dao.MessageDao;
import dao.RecordDao;
import model.Record;
import java.sql.Timestamp;
import model.Message;

/**
 * CRUD(create, read, update, delete)
 * @author wind
 *
 */
public class MessageDaoImpl extends BaseDaoImpl<Message, Integer> implements MessageDao {

    /**
     * @param record
     * @return
     */
    @Override
    public int insert(Message record){
        String sql = "insert into message values(?, ?, ?, ?, ?)";
        return super.executeUpdate(sql, ps -> {
            ps.setString(1, null);
            ps.setInt(2, record.getSendId());
            ps.setInt(3, record.getReceiveId());
            ps.setString(4, record.getMessage());
            ps.setTimestamp(5, new Timestamp(record.getDate().getTime()));
        });
    }

    /**
     * @param id
     * @return
     */
    @Override
    public int deleteById(Integer id){
        String sql = "delete from message where id = ?";
        return super.executeUpdate(sql, ps -> ps.setInt(1, id));
    }


    /**
     * @param id
     * @return
     */
    @Override
    public Message findById(Integer id){
        String sql = "select * from message where id = ?";
        List<Message> entitys = super.executeQuery(sql, ps -> ps.setInt(1, id));
        if(entitys.size() == 1){
            return entitys.get(0);
        }
        return null;
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public List<Message> findByCondition(Message entity) {
        String sql = "select r.*, u.username send_name, b.username receive_name from message r left join user u on r.send_id = u.id left join user b on b.id = r.receive_id where 1 = 1 ";
        String whereClause = "";

        Integer userId = entity.getUserId();
        if(userId != null){
            whereClause += "and (r.send_id = " + userId + " or r.receive_id = " + userId + ")";
        }
        
        String message = entity.getMessage();
        if(message != null){
            whereClause += " and r.message like '%" + message + "%' ";
        }
        
        sql += whereClause;
        System.out.println(sql);
        return super.executeQuery(sql, ps -> {});
    }


    /**
     *
     * @param entity
     * @return
     */
    @Override
    public int updateConditionById(Message entity) {
        String sql = "update message ";
        String setSql = "set ";

     
//        Integer status = entity.getStatus();
//        if(status != null){
//            setSql += ("status = '" + status + "', ");
//        }

        Integer id = entity.getId();
        if(id != null && setSql.contains(",")){
            sql += setSql.substring(0, setSql.length() - 2);
            sql += " where id = ?";

            return super.executeUpdate(sql, ps -> ps.setInt(1, id));
        }

        return -1;
    }

    @Override
    public Message parseTable(ResultSet rs) throws SQLException {
        Message record = new Message();
        record.setId(rs.getInt("id"));
        try{
            record.setSendName(rs.getString("send_name"));
            record.setReceiveName(rs.getString("receive_name"));
        }catch(Exception e){
            
        }
        record.setMessage(rs.getString("message"));
        record.setSendId(rs.getInt("send_id"));
        record.setReceiveId(rs.getInt("receive_id"));
        record.setDate(rs.getTimestamp("date"));
        return record;
    }
}
