package dao.impl;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import model.Book;
import dao.base.BaseDaoImpl;
import dao.BookDao;
import dao.RecordDao;
import model.Record;
import java.sql.Timestamp;

/**
 * CRUD(create, read, update, delete)
 * @author wind
 *
 */
public class RecordDaoImpl extends BaseDaoImpl<Record, Integer> implements RecordDao {

    /**
     * @param record
     * @return
     */
    @Override
    public int insert(Record record){
        String sql = "insert into record values(?, ?, ?, ?, ?)";
        return super.executeUpdate(sql, ps -> {
            ps.setString(1, null);
            ps.setInt(2, record.getBookId());
            ps.setInt(3, record.getUserId());
            ps.setTimestamp(4, new Timestamp(record.getDate().getTime()));
            ps.setInt(5, record.getStatus());
        });
    }

    /**
     * @param id
     * @return
     */
    @Override
    public int deleteById(Integer id){
        String sql = "delete from record where id = ?";
        return super.executeUpdate(sql, ps -> ps.setInt(1, id));
    }


    /**
     * @param id
     * @return
     */
    @Override
    public Record findById(Integer id){
        String sql = "select * from record where id = ?";
        List<Record> entitys = super.executeQuery(sql, ps -> ps.setInt(1, id));
        if(entitys.size() == 1){
            return entitys.get(0);
        }
        return null;
    }

    /**
     * @param entity
     * @return
     */
    @Override
    public List<Record> findByCondition(Record entity) {
        String sql = "select r.*, u.username, b.name book_name from record r left join user u on r.user_id = u.id left join book b on b.id = r.book_id where 1 = 1 ";
        String whereClause = "";

        Integer status = entity.getStatus();
        if(status != null){
            whereClause += "and r.status = " + status + " ";
        }
        
        Integer providerId = entity.getProviderId();
        if(status != null){
            whereClause += "and b.user_id = " + providerId + " ";
        }

        String bookName = entity.getBookName();
        if(bookName != null){
            whereClause += "and b.name like '%" + bookName + "%' ";
        }

        sql += whereClause;
        return super.executeQuery(sql, ps -> {});
    }


    /**
     *
     * @param entity
     * @return
     */
    @Override
    public int updateConditionById(Record entity) {
        String sql = "update record ";
        String setSql = "set ";

     
        Integer status = entity.getStatus();
        if(status != null){
            setSql += ("status = '" + status + "', ");
        }

        Integer id = entity.getId();
        if(id != null && setSql.contains(",")){
            sql += setSql.substring(0, setSql.length() - 2);
            sql += " where id = ?";

            return super.executeUpdate(sql, ps -> ps.setInt(1, id));
        }

        return -1;
    }

    @Override
    public Record parseTable(ResultSet rs) throws SQLException {
        Record record = new Record();
        record.setId(rs.getInt("id"));
        try{
            record.setBookName(rs.getString("book_name"));
            record.setUsername(rs.getString("username"));
        }catch(Exception e){
            
        }
        record.setUserId(rs.getInt("user_id"));
        record.setStatus(rs.getInt("status"));
        record.setBookId(rs.getInt("book_id"));
        record.setDate(rs.getTimestamp("date"));
        return record;
    }
}
