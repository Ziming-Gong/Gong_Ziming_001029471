/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dao.base.BaseDao;
import model.User;

/**
 *
 * @author follow
 */
public interface UserDao    extends BaseDao<User, Integer> {
    
    /**
     * login
     * @param username
     * @param password
     * @return 
     */
    User login(String username, String password);
    
    /**
     * findByName
     * @param username
     * @return 
     */
    User findByName(String username);
}
