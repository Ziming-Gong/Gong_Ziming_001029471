/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enums;

/**
 *
 * @author follow
 */
public enum UserType {
    
    SYSADMIN("sysadmin", 0),
    
    BOOK_PROVIDER("book provider", 1),
    
    PRINTING_HOUSING("printing housing", 2),
   
    LIBRARY("library", 3),
    
    STUDENT("student", 4),
    ;
        
    private final String name;
    
    private final Integer code;

    private UserType(String name, Integer code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public Integer getCode() {
        return code;
    }
    
    public boolean equalCode(String code){
        return String.valueOf(this.code).equals(code);
    }
    
    public static String getName(String code){
        if(LIBRARY.equalCode(code)){
            return "library";
        }else if(BOOK_PROVIDER.equalCode(code)){
            return "book provider";
        }else if(PRINTING_HOUSING.equalCode(code)){
            return "printing housing";
        }else if(STUDENT.equalCode(code)){
            return "student";
        }else{
            return "sysadmin";
        }
    }
}
