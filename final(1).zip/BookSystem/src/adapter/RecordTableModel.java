package adapter;

import enums.StatusType;
import java.text.SimpleDateFormat;
import model.Book;

import java.util.List;

import javax.swing.table.AbstractTableModel;
import model.Record;

/**
 * @package adapter
 * @className BookTableModel
 * @note TODO
 * @author wind
 */
public class RecordTableModel extends AbstractTableModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<Record> entityList;
        private String[] columns = { "id", "bookName", "studentNo", "status", "date"};
    
	public RecordTableModel(List<Record> entityList) {
		super();
		this.entityList = entityList;
	}

	@Override
	public int getRowCount() {
		return entityList.size();
	}

	@Override
	public int getColumnCount() {
		return columns.length;
	}
	
	@Override
	public String getColumnName(int column) {
		return columns[column];
	}
	
	private Object getColumn(Record entity, int n) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            switch (n) {
                case 0: return entity.getId();
                case 1: return entity.getBookName();
                case 2: return entity.getUsername();
                case 3: return entity.getStatus() == 0 ? "renting":"the return";
                case 4: return format.format(entity.getDate());
                default: return null;
            }
        }

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return getColumn(entityList.get(rowIndex), columnIndex);
	}

}
