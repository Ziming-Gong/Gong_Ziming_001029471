package adapter;

import enums.StatusType;
import java.text.SimpleDateFormat;
import model.Book;

import java.util.List;

import javax.swing.table.AbstractTableModel;
import model.Message;

/**
 * @package adapter
 * @className BookTableModel
 * @note TODO
 * @author wind
 */
public class MessageTableModel extends AbstractTableModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<Message> entityList;
        private String[] columns = { "id", "sendName", "receiveName", "message", "date"};
    
	public MessageTableModel(List<Message> entityList) {
		super();
		this.entityList = entityList;
	}

	@Override
	public int getRowCount() {
		return entityList.size();
	}

	@Override
	public int getColumnCount() {
		return columns.length;
	}
	
	@Override
	public String getColumnName(int column) {
		return columns[column];
	}
	
	private Object getColumn(Message entity, int n) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            switch (n) {
                case 0: return entity.getId();
                case 1: return entity.getSendName();
                case 2: return entity.getReceiveName();
                case 3: return entity.getMessage();
                case 4: return format.format(entity.getDate());
                default: return null;
            }
        }

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return getColumn(entityList.get(rowIndex), columnIndex);
	}

}
