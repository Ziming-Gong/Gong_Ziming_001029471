package Business;

import Business.Customer.Customer;
import Business.Employee.Employee;
import Business.Role.CustomerRole;
import Business.Role.SystemAdminRole;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author rrheg
 */
public class ConfigureASystem {
    
    public static EcoSystem configure(){
        
        EcoSystem system = EcoSystem.getInstance();
        
        //Create a network
        ArrayList<Network> networklist;
        //create an enterprise
        //initialize some organizations
        //have some employees 
        //create user account
        
        
        
        
        Employee employee = system.getEmployeeDirectory().createEmployee("RRH");
        
        UserAccount ua = system.getUserAccountDirectory().createUserAccount("1", "1", employee, new SystemAdminRole());
        
        return system;
    }

    private static class Network {

        public Network() {
        }
    }
    
}
