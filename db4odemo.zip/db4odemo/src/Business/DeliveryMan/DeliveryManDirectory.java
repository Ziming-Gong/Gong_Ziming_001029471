/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.DeliveryMan;

import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class DeliveryManDirectory {
    
    private ArrayList<DeliveryMan> deliverymanList;
    
    public DeliveryManDirectory(){
        deliverymanList = new ArrayList();
    }

    public ArrayList<DeliveryMan> getDeliverymanList() {
        return deliverymanList;
    }
    
    public DeliveryMan createdeliveryman(String name){
        DeliveryMan man = new DeliveryMan();
        man.setName(name);
        deliverymanList.add(man);
        return man;
    }
    
}
